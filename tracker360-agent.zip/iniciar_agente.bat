@echo off
title Tracker360 - Agente de Impresion Local
echo [Paso 1/2] Instalando librerias necesarias...
pip install -r requirements.txt -q
echo [Paso 2/2] Iniciando Agente de Impresion...
python main.py
pause

import time
import requests
import win32print

API_URL = "https://tracker360.mywire.org/api/admin/print-queue"
PRINTER_NAME = win32print.GetDefaultPrinter()

while True:
    try:
        res = requests.get(API_URL, timeout=5)
        if res.status_code == 200:
            for job in res.json():
                raw = job['zpl_content'].encode('utf-8')
                h = win32print.OpenPrinter(PRINTER_NAME)
                try:
                    win32print.StartDocPrinter(h, 1, ("Tracker360", None, "RAW"))
                    win32print.StartPagePrinter(h)
                    win32print.WritePrinter(h, raw)
                    win32print.EndPagePrinter(h)
                    win32print.EndDocPrinter(h)
                finally:
                    win32print.ClosePrinter(h)
                requests.put(f"{API_URL}/{job['id']}")
    except:
        pass
    time.sleep(3)
@echo off
TITLE Instalador Tracker360
color 1F
echo [1/3] Verificando instalacion de Python...
python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 ( echo ERROR: Python no esta instalado o falta en el PATH. & pause & exit /b )
echo [2/3] Instalando librerias...
pip install requests pywin32 >nul 2>&1
echo [3/3] Registrando tarea invisible en Windows...
set "A=%~dp0agente_zebra.py"
schtasks /create /tn "Tracker360_Print_Agent" /tr "pythonw.exe \"%A%\"" /sc onlogon /rl highest /f
start pythonw.exe "%A%"
echo.
echo [EXITO] Instalacion completa. El agente ya esta operando de fondo.
pause